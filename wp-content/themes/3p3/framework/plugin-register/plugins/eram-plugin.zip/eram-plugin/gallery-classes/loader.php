<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require_once (dirname(__FILE__).'/eg_class.php');
require_once (dirname(__FILE__).'/eg_simple_horizontal_class.php');
require_once (dirname(__FILE__).'/eg_simple_vertical_class.php');
require_once (dirname(__FILE__).'/eg_masonry_class.php');
require_once (dirname(__FILE__).'/eg_h_masonry_class.php');
require_once (dirname(__FILE__).'/eg_v_masonry_class.php');
require_once (dirname(__FILE__).'/eg_grid_class.php');
require_once (dirname(__FILE__).'/eg_h_grid_class.php');
require_once (dirname(__FILE__).'/eg_v_grid_class.php');
require_once (dirname(__FILE__).'/eg_justified_class.php');
require_once (dirname(__FILE__).'/eg_slider_class.php');
require_once (dirname(__FILE__).'/eg_kenburn_class.php');
require_once (dirname(__FILE__).'/eg_dcarousel_class.php');
require_once (dirname(__FILE__).'/eg_proofing_class.php');
require_once (dirname(__FILE__).'/eg_client_class.php');
require_once (dirname(__FILE__).'/eg_pf_justified_class.php');
require_once (dirname(__FILE__).'/eg_pf_v_grid_class.php');
require_once (dirname(__FILE__).'/eg_pf_v_masonry_class.php');
require_once (dirname(__FILE__).'/eg_pf_minimal_class.php');